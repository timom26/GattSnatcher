#pragma once


#define MAX_NUM_REPORTS 0x19
#define UART_MAGIC_PREFIX "ADV:"
