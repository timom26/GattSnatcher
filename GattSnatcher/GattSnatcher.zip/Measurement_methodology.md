# Measurement Methodology

| Class      | Common Actions                  |
|------------|---------------------------------|
| Lock       | Lock/Unlock                     |
| Light Bulb | On/Off, Luminance Level, Effect |
| Actuator   | On/Off                          |
| Sensor     | Receive Data                    |

## Setup

To ensure generality, measurements were made in two environments:

1. **Shielded chamber** (ID: clean) - The first environment is a shielded chamber with minimal external radio interference to provide a clean data set.
2. **Office** (ID: office) - The second environment is a common workplace with several active Bluetooth and WiFi transmitters in the vicinity that represent realistic working conditions.

`NOTE: IglooHome was measured in Shielded chamber with door open, because it needs WIFI connection`

In both environments, the monitoring setup consists of exactly one device to be measured, an Android device (smartphone or tablet) with the appropriate control app and a monitoring probe. The three devices are placed approximately 50 cm apart in one level (on a table top) and form an equilateral triangle with no obstacles between the devices. The monitoring probe is controlled from a laptop connected by an ethernet cable with radio transmitters (WiFi, Bluetooth) switched off.

## Measuring

For every device we have selected several events which we measure based on the device features (described in the [/devices](./devices) folder). Every measurement contains 1 minute data collection with 20 seconds of no action intended for the models to initialise, followed by one occurence of the measured event as described, and the rest is again no action. 

As the monitoring probe is able of performing two types of monitoring - the monitoring via internal Bluetooth chip as described in the paper *Indirect Bluetooth Low Energy Connection Detection* (controller folder), and the multi-channel approach described in this paper (parallel folder), every measurement is performed via both methods to allow for comparison. Every measurement was repeated 5 times to account for the measurement errors.

### Lock

**Danalock** (ID: danalock)
- passive: No action, control app not running
- unlock: Unlock the smart lock in the app
- lock: Lock the smart lock in the app
- coldUnlock: Start the control app, unlock the smart lock, close the app
- coldLock: Start the control app, lock the smart lock, close the app

**Nuki Smart Lock** (ID: nuki)
- passive: No action, control app not running
- unlock: Unlock the smart lock in the app
- lock: Lock the smart lock in the app
- coldUnlock: Start the control app, unlock the smart lock, close the app
- coldLock: Start the control app, lock the smart lock, close the app
- log: Go to lock settings in the app and display the activity log

**igloohome Padlock Lite** (ID: igloohome)
- passive: No action, control app not running
- unlock: Unlock the smart lock in the app
- lock: Lock the smart lock in the app
- coldUnlock: Start the control app, unlock the smart lock, close the app
- coldLock: Start the control app, lock the smart lock, close the app
- log: Go to lock details > Logs tab and click the "Get recent logs"

**Bentech FP3** (ID: bentech)
- passive: No action, control app not running
- unlock: Unlock the smart lock in the app
- coldUnlock: Start the control app, unlock the smart lock, close the app

### Light Bulb

**Phillips Hue white** (ID: hueBulb)
- passive: No action, control app not running
- on: Switch the bulb on with the widget
- off: Switch the bulb off with the widget
- coldOn: Start the control app, switch the bulb on with the widget, close the app
- coldOff: Start the control app, switch the bulb off with the widget, close the app
- configOn: Open the bulb config (click on the widget), switch the bulb on, go back to overview
- configOff: Open the bulb config (click on the widget), switch the bulb off, go back to overview
- luminance: Open the bulb config (click on the widget), change the luminance level, go back to overview
- effect: Open the bulb config (click on the widget), select the effect, go back to overview

**Revogi Bluetooth LED bulb** (ID: revogi)
- passive: No action, control app not running
- on: Switch the bulb on in the list of connected devices
- off: Switch the bulb off in the list of connected devices
- coldOn: Start the control app, switch the bulb on in the list of connected devices, close the app
- coldOff: Start the control app, switch the bulb off in the list of connected devices, close the app
- configOn: Select the bulb in the list of connected devices, switch the bulb on, go back to the list of connected devices
- configOff: Select the bulb in the list of connected devices, switch the bulb on, go back to the list of connected devices
- luminance: Select the bulb in the list of connected devices, change the luminance level, go back to the list of connected devices
- effect: Select the bulb in the list of connected devices, select the effect, go back to the list of connected devices
- colour: Select the bulb in the list of connected devices, change the hue, go back to the list of connected devices

### Actuator

**Phillips Hue Smart plug** (ID: huePlug)
- passive: No action, control app not running
- on: Switch the plug on with the widget
- off: Switch the plug off with the widget
- coldOn: Start the control app, switch the plug on with the widget, close the app
- coldOff: Start the control app, switch the plug off with the widget, close the app

### Sensor

**Mi Temperature and Humidity Monitor 2** (ID: miTemp)
- passive: No action, control app not running
- data: Select the "Temperature & humidity" widget, wait until the data is loaded (including the history graph), go back to the app home screen
- coldData: Start the control app, select the "Temperature & humidity" widget, wait until the data is loaded (including the history graph), go back to app home screen

**BeeWi Motion Sensor** (ID: beeWiMotion)
- passive: No action, control app not running
- data: Cause a motion detection
- expandedData: Select the motion sensor widget, cause a motion detection

**BeeWi Door/Window Sensor** (ID: beeWiOpen)
- passive: No action, control app not running
- data: Select the door/window widget, cause an open/close detection, go back to the app home screen
- expandedData: Start the control app, select the door/window widget, cause an open/close detection, close the app

